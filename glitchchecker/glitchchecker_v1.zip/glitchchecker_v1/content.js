chrome.runtime.sendMessage({type: 'sendMessage'});
//https://status.firebase.google.com/incidents.json

/*

chrome.runtime.onMessage.addListener(async (message, sender, sendResponse)  =>{
  if (message.action != "from_background") {
    return false
  }
  const ret = []
  for(let data of message.data){
    const name = data.name
    const url  = data.url
    if (!data.feed){
      ret.push({name:name,url:url,data:false})
      continue;
    }
    try{
      const dom = new DOMParser().parseFromString(data.feed, "text/xml")
      let feed = false
      if (name == "slack"){
        feed = parseDom(name, dom)
      }
      if (name == "GitHub"){
        feed = parseDom(name, dom)
      }
      console.log(name)
      console.log(feed)
      ret.push({name:name,url:url,data:feed})
    } catch (err){
      ret.push({name:name,url:url,data:false})
    }
  }
  await chrome.runtime.sendMessage({type: "from_content", data:ret})
});


function parseDom(type,dom){
  const ret = {}
  let update = false
  if (type == "slack"){
    update = dom.getElementsByTagName('lastBuildDate')[0].textContent
  }
  if (type == "GitHub" || type == "CircleCI"){
    update = dom.getElementsByTagName('pubDate')[0].textContent
  }

  if (update){
    ret["lastUpdate"] = update
  }
  
  const items = dom.getElementsByTagName('item')
  const data = []
  for(let i = 0; i < items.length; i++){
    const title = items[i].getElementsByTagName('title')[0].textContent
    const description = items[i].getElementsByTagName('description')[0].textContent
    const pubDate     = items[i].getElementsByTagName('pubDate')[0].textContent
    const link        = items[i].getElementsByTagName('link')[0].textContent
    const t =  {title:title,description:description,pubDate,link}
    data.push(t)
  }
  ret["data"] = data
  return ret
}
*/